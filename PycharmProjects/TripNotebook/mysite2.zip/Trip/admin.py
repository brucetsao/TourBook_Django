from django.contrib import admin
from Trip.models import TripMain,Plan

# Register your models here.
admin.site.register(TripMain)
admin.site.register(Plan)